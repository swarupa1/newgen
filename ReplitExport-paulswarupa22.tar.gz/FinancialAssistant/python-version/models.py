"""
Database models for the finance chatbot application
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from typing import Dict, Any
import uuid

db = SQLAlchemy()

class User(db.Model):
    """User model for authentication"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship to messages
    messages = db.relationship('Message', backref='user', lazy=True)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'username': self.username,
            'created_at': self.created_at.isoformat()
        }

class Message(db.Model):
    """Message model for chat history"""
    __tablename__ = 'messages'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    content = db.Column(db.Text, nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'user' or 'assistant'
    session_id = db.Column(db.String(100), nullable=False, index=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    # Foreign key to user (optional)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'content': self.content,
            'role': self.role,
            'sessionId': self.session_id,
            'timestamp': self.timestamp.isoformat(),
            'user_id': self.user_id
        }
    
    @classmethod
    def get_session_messages(cls, session_id: str, limit: int = 50):
        """Get messages for a specific session"""
        return cls.query.filter_by(session_id=session_id)\
                      .order_by(cls.timestamp.asc())\
                      .limit(limit)\
                      .all()
    
    @classmethod
    def create_message(cls, content: str, role: str, session_id: str, user_id: int = None):
        """Create a new message"""
        message = cls(
            content=content,
            role=role,
            session_id=session_id,
            user_id=user_id
        )
        db.session.add(message)
        db.session.commit()
        return message