# Finance Chatbot - Python Flask Backend

A Python Flask-based finance chatbot that provides AI-powered financial education and guidance.

## 🚀 Features

- **AI-Powered Responses**: Uses Hugging Face API for intelligent financial advice
- **Web Interface**: Built-in web interface with modern design
- **Database Support**: SQLAlchemy with SQLite/PostgreSQL support
- **RESTful API**: Clean API endpoints for integration
- **Error Handling**: Comprehensive error handling and fallback responses
- **Session Management**: Conversation history tracking
- **Health Monitoring**: Built-in health check and statistics endpoints

## 📋 Requirements

- Python 3.8+
- Flask 3.0+
- SQLAlchemy
- Hugging Face API key (optional - fallback responses available)

## 🛠️ Installation

### 1. Clone and Setup
```bash
git clone <repository-url>
cd python-version
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Environment Configuration
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Environment Variables
```env
FLASK_ENV=development
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///finance_bot.db
HUGGINGFACE_API_KEY=your-huggingface-api-key-here
PORT=5000
```

### 4. Run the Application
```bash
# Simple version (in-memory storage)
python app.py

# Full version (with database)
python run.py

# Or with Flask CLI
flask run
```

## 📁 Project Structure

```
python-version/
├── app.py                    # Simple Flask app with in-memory storage
├── app_with_db.py           # Full Flask app with database
├── run.py                   # Application entry point
├── config.py                # Configuration settings
├── models.py                # SQLAlchemy database models
├── requirements.txt         # Python dependencies
├── .env.example            # Environment variables template
├── services/
│   └── ai_service.py       # AI service for Hugging Face integration
└── README.md               # This file
```

## 🌐 API Endpoints

### Core Endpoints
- `GET /` - Web interface
- `POST /api/messages` - Send message and get AI response
- `GET /api/messages/<session_id>` - Get conversation history
- `GET /health` - Health check
- `GET /api/stats` - Application statistics

### API Usage Examples

#### Send Message
```bash
curl -X POST http://localhost:5000/api/messages \
  -H "Content-Type: application/json" \
  -d '{
    "content": "What are ETFs?",
    "role": "user",
    "sessionId": "session_123"
  }'
```

#### Get Messages
```bash
curl http://localhost:5000/api/messages/session_123
```

## 🔧 Configuration Options

### Database Configuration
```python
# SQLite (default)
DATABASE_URL=sqlite:///finance_bot.db

# PostgreSQL
DATABASE_URL=postgresql://username:password@localhost/finance_bot

# In-memory (for testing)
DATABASE_URL=sqlite:///:memory:
```

### AI Service Configuration
The application supports multiple AI service configurations:
- **Hugging Face API**: Primary AI service
- **Fallback Responses**: Topic-based responses when AI is unavailable
- **Custom Models**: Easy to extend with other AI services

## 🐳 Docker Deployment

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["python", "run.py"]
```

```bash
docker build -t finance-chatbot .
docker run -p 5000:5000 -e HUGGINGFACE_API_KEY=your_key finance-chatbot
```

## 🚀 Production Deployment

### Heroku
```bash
# Create Procfile
echo "web: gunicorn run:app" > Procfile

# Deploy
heroku create your-finance-bot
heroku config:set HUGGINGFACE_API_KEY=your_key
git push heroku main
```

### Railway/Render
1. Connect your GitHub repository
2. Set environment variables
3. Use start command: `python run.py`

### Traditional Server
```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn
gunicorn --bind 0.0.0.0:5000 run:app
```

## 🔐 Security Features

- **Environment Variables**: Sensitive data stored in environment variables
- **Input Validation**: Request data validation
- **SQL Injection Protection**: SQLAlchemy ORM prevents SQL injection
- **CORS Configuration**: Configurable CORS origins
- **Error Handling**: Secure error messages

## 📊 Monitoring and Logging

### Built-in Endpoints
- `/health` - Application health status
- `/api/stats` - Usage statistics

### Logging
```python
import logging
logging.basicConfig(level=logging.INFO)
```

## 🧪 Testing

```bash
# Run simple tests
python -c "
from app_with_db import create_app
app = create_app('testing')
with app.app_context():
    print('Application created successfully!')
"
```

## 🔄 Comparison with Node.js Version

| Feature | Python Flask | Node.js Express |
|---------|-------------|-----------------|
| **Language** | Python | TypeScript/JavaScript |
| **Framework** | Flask | Express.js |
| **Database** | SQLAlchemy | Drizzle ORM |
| **Frontend** | Built-in HTML | React + Vite |
| **AI Service** | Hugging Face | Hugging Face |
| **Deployment** | Docker, Heroku | Vercel, Railway |

## 📝 Development Notes

### Key Python Libraries Used
- **Flask**: Web framework
- **SQLAlchemy**: Database ORM
- **Flask-CORS**: Cross-origin resource sharing
- **Requests**: HTTP client for AI API calls
- **Python-dotenv**: Environment variable management

### Architecture Highlights
- **Application Factory Pattern**: Modular app creation
- **Service Layer**: Separated AI logic
- **Configuration Classes**: Environment-specific settings
- **Error Handling**: Comprehensive exception handling
- **Logging**: Structured logging throughout

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.

---

**Disclaimer**: This application provides educational financial information only and should not be considered as professional financial advice.