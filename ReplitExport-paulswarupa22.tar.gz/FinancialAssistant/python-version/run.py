"""
Entry point for the Finance Chatbot Flask application
"""

import os
from app_with_db import create_app
from models import db

def main():
    """Main entry point"""
    # Create the application
    app = create_app()
    
    # Get configuration
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV', 'development') == 'development'
    host = '0.0.0.0'  # Allow external connections
    
    print(f"🏦 Finance Chatbot starting on http://{host}:{port}")
    print(f"Environment: {os.environ.get('FLASK_ENV', 'development')}")
    print(f"Debug mode: {debug}")
    
    # Run the application
    app.run(host=host, port=port, debug=debug)

if __name__ == '__main__':
    main()