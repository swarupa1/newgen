"""
Finance Chatbot - Python Flask Backend
A Flask-based API server for the finance chatbot application.
"""

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
import requests
import json
from datetime import datetime
from typing import List, Dict, Optional
import uuid

app = Flask(__name__)
CORS(app)

# In-memory storage for messages (replace with database in production)
messages_storage = {}

class Message:
    def __init__(self, content: str, role: str, session_id: str):
        self.id = str(uuid.uuid4())
        self.content = content
        self.role = role  # 'user' or 'assistant'
        self.session_id = session_id
        self.timestamp = datetime.utcnow().isoformat()

    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'role': self.role,
            'sessionId': self.session_id,
            'timestamp': self.timestamp
        }

def get_huggingface_response(messages: List[Dict[str, str]]) -> str:
    """
    Generate AI response using Hugging Face API
    """
    try:
        api_key = os.getenv('HUGGINGFACE_API_KEY')
        if not api_key:
            return get_fallback_response(messages)
        
        system_prompt = """You are FinanceBot, an AI financial assistant specialized in providing helpful, accurate, and educational information about finance, investing, and markets. 

Key guidelines:
- Provide clear, educational responses about financial topics
- Use simple language that both beginners and professionals can understand
- Include relevant examples when helpful
- Always remind users that this is educational information, not personalized financial advice
- Focus on topics like: stocks, bonds, ETFs, investing basics, market terminology, financial planning concepts
- If asked about specific stock picks or investment recommendations, politely redirect to general education
- Be professional yet approachable
- Keep responses concise but comprehensive

Remember: Always include a disclaimer that this is educational information only and users should consult with qualified financial professionals for personalized advice."""

        # Build conversation context
        conversation_text = "\n\n".join([
            f"{'Human' if msg['role'] == 'user' else 'Assistant'}: {msg['content']}"
            for msg in messages
        ])
        
        prompt = f"{system_prompt}\n\nConversation:\n{conversation_text}\n\nAssistant:"
        
        # Try primary model
        response = requests.post(
            'https://api-inference.huggingface.co/models/microsoft/DialoGPT-large',
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            },
            json={
                'inputs': prompt,
                'parameters': {
                    'max_length': 1000,
                    'temperature': 0.7,
                    'do_sample': True,
                    'top_p': 0.9,
                    'repetition_penalty': 1.1
                }
            },
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            ai_response = data.get('generated_text', '') or (data[0].get('generated_text', '') if isinstance(data, list) else '')
            
            # Clean up response
            clean_response = ai_response.replace(prompt, '').strip()
            return f"{clean_response}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*"
        
        # Try fallback model
        fallback_response = requests.post(
            'https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill',
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            },
            json={
                'inputs': conversation_text,
                'parameters': {
                    'max_length': 500,
                    'temperature': 0.7
                }
            },
            timeout=30
        )
        
        if fallback_response.status_code == 200:
            data = fallback_response.json()
            ai_response = data.get('generated_text', '') or (data[0].get('generated_text', '') if isinstance(data, list) else '')
            return f"{ai_response}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*"
        
        return get_fallback_response(messages)
        
    except Exception as e:
        print(f"Hugging Face API error: {e}")
        return get_fallback_response(messages)

def get_fallback_response(messages: List[Dict[str, str]]) -> str:
    """
    Provide fallback responses for common financial topics
    """
    last_user_message = ""
    for msg in reversed(messages):
        if msg['role'] == 'user':
            last_user_message = msg['content'].lower()
            break
    
    fallback_response = "I'm FinanceBot, your AI financial assistant. I'm here to help with questions about investing, markets, and financial concepts."
    
    if 'etf' in last_user_message:
        fallback_response = "ETFs (Exchange-Traded Funds) are investment funds that trade on stock exchanges like individual stocks. They typically track an index, commodity, bonds, or a basket of assets, offering diversification at a lower cost than mutual funds."
    elif 'stock' in last_user_message or 'share' in last_user_message:
        fallback_response = "Stocks represent ownership shares in a company. When you buy stock, you become a shareholder and own a small piece of that business. Stock prices fluctuate based on company performance and market conditions."
    elif 'bond' in last_user_message:
        fallback_response = "Bonds are debt securities where you lend money to an entity (government or corporation) for a defined period at a fixed interest rate. They're generally considered safer than stocks but with lower potential returns."
    elif 'invest' in last_user_message:
        fallback_response = "Investing involves putting money into assets with the expectation of generating returns over time. Key principles include diversification, understanding risk tolerance, and having a long-term perspective."
    elif 'compound interest' in last_user_message:
        fallback_response = "Compound interest is the interest earned on both the initial principal and previously earned interest. It's often called 'interest on interest' and is a powerful wealth-building tool over time. The earlier you start investing, the more compound interest can work in your favor."
    elif 'risk' in last_user_message and 'return' in last_user_message:
        fallback_response = "Risk and return are directly related in investing. Generally, higher potential returns come with higher risk. Lower-risk investments like bonds typically offer smaller returns, while higher-risk investments like stocks can offer greater returns but with more volatility."
    elif 'dollar cost averaging' in last_user_message or 'dca' in last_user_message:
        fallback_response = "Dollar-cost averaging is an investment strategy where you invest a fixed amount regularly, regardless of market conditions. This helps reduce the impact of market volatility by buying more shares when prices are low and fewer when prices are high."
    
    return f"{fallback_response}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*"

@app.route('/')
def index():
    """Serve the main application page"""
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Finance Bot</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
            .chat-container { border: 1px solid #ddd; height: 400px; overflow-y: auto; padding: 10px; margin-bottom: 10px; }
            .message { margin-bottom: 10px; padding: 8px; border-radius: 5px; }
            .user { background-color: #e3f2fd; text-align: right; }
            .assistant { background-color: #f5f5f5; }
            .input-container { display: flex; gap: 10px; }
            input[type="text"] { flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
            button { padding: 10px 20px; background-color: #1976d2; color: white; border: none; border-radius: 5px; cursor: pointer; }
            button:hover { background-color: #1565c0; }
        </style>
    </head>
    <body>
        <h1>🏦 Finance Bot</h1>
        <div id="chat-container" class="chat-container"></div>
        <div class="input-container">
            <input type="text" id="message-input" placeholder="Ask me about finance, investments, market terms..." />
            <button onclick="sendMessage()">Send</button>
        </div>
        
        <script>
            const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            
            async function sendMessage() {
                const input = document.getElementById('message-input');
                const message = input.value.trim();
                if (!message) return;
                
                // Add user message to chat
                addMessageToChat(message, 'user');
                input.value = '';
                
                try {
                    const response = await fetch('/api/messages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            content: message,
                            role: 'user',
                            sessionId: sessionId
                        })
                    });
                    
                    const data = await response.json();
                    if (data.assistantMessage) {
                        addMessageToChat(data.assistantMessage.content, 'assistant');
                    }
                } catch (error) {
                    addMessageToChat('Sorry, I encountered an error. Please try again.', 'assistant');
                }
            }
            
            function addMessageToChat(content, role) {
                const chatContainer = document.getElementById('chat-container');
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${role}`;
                messageDiv.textContent = content;
                chatContainer.appendChild(messageDiv);
                chatContainer.scrollTop = chatContainer.scrollHeight;
            }
            
            // Allow Enter key to send message
            document.getElementById('message-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
        </script>
    </body>
    </html>
    """

@app.route('/api/messages/<session_id>', methods=['GET'])
def get_messages(session_id: str):
    """Get chat history for a session"""
    try:
        session_messages = messages_storage.get(session_id, [])
        return jsonify([msg.to_dict() for msg in session_messages])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/messages', methods=['POST'])
def send_message():
    """Send a message and get AI response"""
    try:
        data = request.get_json()
        content = data.get('content', '').strip()
        role = data.get('role', 'user')
        session_id = data.get('sessionId')
        
        if not content or not session_id:
            return jsonify({'error': 'Missing content or sessionId'}), 400
        
        # Save user message
        user_message = Message(content, role, session_id)
        if session_id not in messages_storage:
            messages_storage[session_id] = []
        messages_storage[session_id].append(user_message)
        
        # Get conversation history for context (last 10 messages)
        conversation_history = messages_storage[session_id][-10:]
        chat_messages = [
            {'role': msg.role, 'content': msg.content}
            for msg in conversation_history
        ]
        
        # Generate AI response
        ai_response_content = get_huggingface_response(chat_messages)
        
        # Save AI response
        assistant_message = Message(ai_response_content, 'assistant', session_id)
        messages_storage[session_id].append(assistant_message)
        
        return jsonify({
            'userMessage': user_message.to_dict(),
            'assistantMessage': assistant_message.to_dict()
        })
        
    except Exception as e:
        print(f"Error processing message: {e}")
        return jsonify({'error': 'Failed to process message'}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('NODE_ENV', 'development') == 'development'
    app.run(host='0.0.0.0', port=port, debug=debug)