"""
Finance Chatbot - Python Flask Backend with Database
Complete Flask application with SQLAlchemy database integration
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
import os
from datetime import datetime
from typing import List, Dict
import logging

from config import config
from models import db, Message, User
from services.ai_service import AIService

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app(config_name: str = None):
    """Application factory pattern"""
    app = Flask(__name__)
    
    # Load configuration
    config_name = config_name or os.environ.get('FLASK_ENV', 'default')
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    CORS(app, origins=app.config['CORS_ORIGINS'])
    
    # Initialize AI service
    ai_service = AIService(app.config['HUGGINGFACE_API_KEY'])
    
    # Create tables
    with app.app_context():
        db.create_all()
    
    @app.route('/')
    def index():
        """Serve a simple web interface"""
        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Finance Bot - Python Backend</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .container { 
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                    width: 100%;
                    max-width: 800px;
                    margin: 20px;
                    overflow: hidden;
                }
                .header {
                    background: #1976d2;
                    color: white;
                    padding: 20px;
                    text-align: center;
                }
                .header h1 { font-size: 24px; margin-bottom: 5px; }
                .header p { opacity: 0.9; font-size: 14px; }
                .chat-container { 
                    height: 400px;
                    overflow-y: auto;
                    padding: 20px;
                    background: #f8f9fa;
                }
                .message { 
                    margin-bottom: 15px;
                    display: flex;
                    align-items: flex-start;
                    gap: 10px;
                }
                .message.user { flex-direction: row-reverse; }
                .message-content {
                    max-width: 70%;
                    padding: 12px 16px;
                    border-radius: 18px;
                    word-wrap: break-word;
                    line-height: 1.4;
                }
                .message.user .message-content {
                    background: #1976d2;
                    color: white;
                    border-bottom-right-radius: 4px;
                }
                .message.assistant .message-content {
                    background: white;
                    border: 1px solid #e0e0e0;
                    border-bottom-left-radius: 4px;
                }
                .avatar {
                    width: 32px;
                    height: 32px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 14px;
                    flex-shrink: 0;
                }
                .avatar.user { background: #1976d2; color: white; }
                .avatar.assistant { background: #e3f2fd; color: #1976d2; }
                .input-container { 
                    padding: 20px;
                    border-top: 1px solid #e0e0e0;
                    background: white;
                }
                .input-form {
                    display: flex;
                    gap: 12px;
                    align-items: center;
                }
                input[type="text"] { 
                    flex: 1;
                    padding: 12px 16px;
                    border: 2px solid #e0e0e0;
                    border-radius: 25px;
                    font-size: 14px;
                    outline: none;
                    transition: border-color 0.2s;
                }
                input[type="text"]:focus { border-color: #1976d2; }
                .send-btn { 
                    padding: 12px 24px;
                    background: #1976d2;
                    color: white;
                    border: none;
                    border-radius: 25px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 500;
                    transition: background-color 0.2s;
                    min-width: 80px;
                }
                .send-btn:hover { background: #1565c0; }
                .send-btn:disabled { background: #ccc; cursor: not-allowed; }
                .typing {
                    display: none;
                    align-items: center;
                    gap: 5px;
                    padding: 10px 0;
                    font-style: italic;
                    color: #666;
                    font-size: 14px;
                }
                .typing-dots {
                    display: inline-flex;
                    gap: 2px;
                }
                .typing-dot {
                    width: 4px;
                    height: 4px;
                    background: #666;
                    border-radius: 50%;
                    animation: typing 1.4s infinite ease-in-out;
                }
                .typing-dot:nth-child(1) { animation-delay: -0.32s; }
                .typing-dot:nth-child(2) { animation-delay: -0.16s; }
                @keyframes typing {
                    0%, 80%, 100% { transform: scale(0.8); opacity: 0.5; }
                    40% { transform: scale(1); opacity: 1; }
                }
                .suggestions {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 8px;
                    margin-top: 15px;
                }
                .suggestion {
                    padding: 8px 12px;
                    background: #e3f2fd;
                    color: #1976d2;
                    border: none;
                    border-radius: 15px;
                    cursor: pointer;
                    font-size: 12px;
                    transition: background-color 0.2s;
                }
                .suggestion:hover { background: #bbdefb; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🏦 Finance Bot</h1>
                    <p>Python Flask Backend • Educational Finance Assistant</p>
                </div>
                
                <div id="chat-container" class="chat-container">
                    <div class="message assistant">
                        <div class="avatar assistant">🤖</div>
                        <div class="message-content">
                            Hello! I'm FinanceBot, your AI financial assistant. I can help you learn about investing, markets, and financial concepts. What would you like to know?
                        </div>
                    </div>
                </div>
                
                <div class="typing" id="typing-indicator">
                    <div class="avatar assistant">🤖</div>
                    <span>FinanceBot is typing</span>
                    <div class="typing-dots">
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                        <div class="typing-dot"></div>
                    </div>
                </div>
                
                <div class="input-container">
                    <div class="input-form">
                        <input type="text" id="message-input" placeholder="Ask me about finance, investments, market terms..." />
                        <button class="send-btn" onclick="sendMessage()" id="send-btn">Send</button>
                    </div>
                    
                    <div class="suggestions" id="suggestions">
                        <button class="suggestion" onclick="sendSuggestion('What are ETFs?')">What are ETFs?</button>
                        <button class="suggestion" onclick="sendSuggestion('Explain compound interest')">Compound Interest</button>
                        <button class="suggestion" onclick="sendSuggestion('Risk vs return basics')">Risk vs Return</button>
                        <button class="suggestion" onclick="sendSuggestion('What is dollar-cost averaging?')">Dollar-Cost Averaging</button>
                    </div>
                </div>
            </div>
            
            <script>
                const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                let messageCount = 0;
                
                async function sendMessage() {
                    const input = document.getElementById('message-input');
                    const message = input.value.trim();
                    if (!message) return;
                    
                    sendSuggestion(message);
                }
                
                async function sendSuggestion(message) {
                    const input = document.getElementById('message-input');
                    const sendBtn = document.getElementById('send-btn');
                    const suggestions = document.getElementById('suggestions');
                    
                    // Hide suggestions after first message
                    if (messageCount === 0) {
                        suggestions.style.display = 'none';
                    }
                    messageCount++;
                    
                    // Add user message to chat
                    addMessageToChat(message, 'user');
                    input.value = '';
                    
                    // Show typing indicator
                    showTyping(true);
                    sendBtn.disabled = true;
                    
                    try {
                        const response = await fetch('/api/messages', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                content: message,
                                role: 'user',
                                sessionId: sessionId
                            })
                        });
                        
                        const data = await response.json();
                        if (data.assistantMessage) {
                            addMessageToChat(data.assistantMessage.content, 'assistant');
                        } else {
                            addMessageToChat('Sorry, I encountered an error. Please try again.', 'assistant');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        addMessageToChat('Sorry, I encountered an error. Please try again.', 'assistant');
                    } finally {
                        showTyping(false);
                        sendBtn.disabled = false;
                        input.focus();
                    }
                }
                
                function addMessageToChat(content, role) {
                    const chatContainer = document.getElementById('chat-container');
                    const messageDiv = document.createElement('div');
                    messageDiv.className = `message ${role}`;
                    
                    const avatar = document.createElement('div');
                    avatar.className = `avatar ${role}`;
                    avatar.textContent = role === 'user' ? '👤' : '🤖';
                    
                    const messageContent = document.createElement('div');
                    messageContent.className = 'message-content';
                    messageContent.textContent = content;
                    
                    messageDiv.appendChild(avatar);
                    messageDiv.appendChild(messageContent);
                    chatContainer.appendChild(messageDiv);
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                }
                
                function showTyping(show) {
                    const typing = document.getElementById('typing-indicator');
                    typing.style.display = show ? 'flex' : 'none';
                    if (show) {
                        const chatContainer = document.getElementById('chat-container');
                        chatContainer.scrollTop = chatContainer.scrollHeight;
                    }
                }
                
                // Allow Enter key to send message
                document.getElementById('message-input').addEventListener('keypress', function(e) {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        sendMessage();
                    }
                });
                
                // Focus input on load
                document.getElementById('message-input').focus();
            </script>
        </body>
        </html>
        """
    
    @app.route('/api/messages/<session_id>', methods=['GET'])
    def get_messages(session_id: str):
        """Get chat history for a session"""
        try:
            messages = Message.get_session_messages(session_id)
            return jsonify([msg.to_dict() for msg in messages])
        except Exception as e:
            logger.error(f"Error fetching messages: {e}")
            return jsonify({'error': 'Failed to fetch messages'}), 500
    
    @app.route('/api/messages', methods=['POST'])
    def send_message():
        """Send a message and get AI response"""
        try:
            data = request.get_json()
            content = data.get('content', '').strip()
            role = data.get('role', 'user')
            session_id = data.get('sessionId')
            
            if not content or not session_id:
                return jsonify({'error': 'Missing content or sessionId'}), 400
            
            # Save user message
            user_message = Message.create_message(content, role, session_id)
            
            # Get conversation history for context (last 10 messages)
            conversation_history = Message.get_session_messages(session_id, limit=10)
            chat_messages = [
                {'role': msg.role, 'content': msg.content}
                for msg in conversation_history
            ]
            
            # Generate AI response
            ai_response_content = ai_service.generate_response(chat_messages)
            
            # Save AI response
            assistant_message = Message.create_message(ai_response_content, 'assistant', session_id)
            
            return jsonify({
                'userMessage': user_message.to_dict(),
                'assistantMessage': assistant_message.to_dict()
            })
            
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            return jsonify({'error': 'Failed to process message'}), 500
    
    @app.route('/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        try:
            # Test database connection
            db.session.execute('SELECT 1')
            db_status = 'healthy'
        except Exception:
            db_status = 'unhealthy'
        
        return jsonify({
            'status': 'healthy',
            'database': db_status,
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        })
    
    @app.route('/api/stats', methods=['GET'])
    def get_stats():
        """Get application statistics"""
        try:
            total_messages = db.session.query(Message).count()
            total_sessions = db.session.query(Message.session_id).distinct().count()
            
            return jsonify({
                'total_messages': total_messages,
                'total_sessions': total_sessions,
                'timestamp': datetime.utcnow().isoformat()
            })
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return jsonify({'error': 'Failed to get statistics'}), 500
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Not found'}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        logger.error(f"Internal server error: {error}")
        return jsonify({'error': 'Internal server error'}), 500
    
    return app

if __name__ == '__main__':
    app = create_app()
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    app.run(host='0.0.0.0', port=port, debug=debug)