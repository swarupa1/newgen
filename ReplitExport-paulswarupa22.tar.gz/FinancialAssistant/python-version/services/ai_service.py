"""
AI service for generating finance-focused responses
"""

import requests
import os
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

class AIService:
    """Service for handling AI interactions"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv('HUGGINGFACE_API_KEY')
        self.primary_model = 'microsoft/DialoGPT-large'
        self.fallback_model = 'facebook/blenderbot-400M-distill'
        self.timeout = 30
        
        self.system_prompt = """You are FinanceBot, an AI financial assistant specialized in providing helpful, accurate, and educational information about finance, investing, and markets. 

Key guidelines:
- Provide clear, educational responses about financial topics
- Use simple language that both beginners and professionals can understand
- Include relevant examples when helpful
- Always remind users that this is educational information, not personalized financial advice
- Focus on topics like: stocks, bonds, ETFs, investing basics, market terminology, financial planning concepts
- If asked about specific stock picks or investment recommendations, politely redirect to general education
- Be professional yet approachable
- Keep responses concise but comprehensive

Remember: Always include a disclaimer that this is educational information only and users should consult with qualified financial professionals for personalized advice."""

    def generate_response(self, messages: List[Dict[str, str]]) -> str:
        """
        Generate AI response for the given conversation history
        
        Args:
            messages: List of message dictionaries with 'role' and 'content' keys
            
        Returns:
            Generated response string
        """
        try:
            if not self.api_key:
                logger.warning("No Hugging Face API key provided, using fallback responses")
                return self._get_fallback_response(messages)
            
            # Try primary model first
            response = self._call_huggingface_api(self.primary_model, messages)
            if response:
                return response
            
            # Try fallback model
            logger.warning("Primary model failed, trying fallback model")
            response = self._call_huggingface_api(self.fallback_model, messages, use_simple_prompt=True)
            if response:
                return response
            
            # Use hardcoded fallback
            logger.warning("All AI models failed, using hardcoded fallback")
            return self._get_fallback_response(messages)
            
        except Exception as e:
            logger.error(f"Error in generate_response: {e}")
            return self._get_fallback_response(messages)

    def _call_huggingface_api(self, model: str, messages: List[Dict[str, str]], use_simple_prompt: bool = False) -> Optional[str]:
        """Call Hugging Face API with the specified model"""
        try:
            if use_simple_prompt:
                # Simple conversation format for fallback model
                prompt = "\n\n".join([
                    f"{'Human' if msg['role'] == 'user' else 'Assistant'}: {msg['content']}"
                    for msg in messages
                ])
            else:
                # Full prompt with system instructions
                conversation_text = "\n\n".join([
                    f"{'Human' if msg['role'] == 'user' else 'Assistant'}: {msg['content']}"
                    for msg in messages
                ])
                prompt = f"{self.system_prompt}\n\nConversation:\n{conversation_text}\n\nAssistant:"
            
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'inputs': prompt,
                'parameters': {
                    'max_length': 1000 if not use_simple_prompt else 500,
                    'temperature': 0.7,
                    'do_sample': True,
                    'top_p': 0.9,
                    'repetition_penalty': 1.1
                }
            }
            
            response = requests.post(
                f'https://api-inference.huggingface.co/models/{model}',
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Handle different response formats
                if isinstance(data, list) and len(data) > 0:
                    ai_response = data[0].get('generated_text', '')
                elif isinstance(data, dict):
                    ai_response = data.get('generated_text', '')
                else:
                    return None
                
                if ai_response:
                    # Clean up the response
                    clean_response = ai_response.replace(prompt, '').strip()
                    if clean_response:
                        return f"{clean_response}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*"
            
            logger.warning(f"API call failed with status {response.status_code}: {response.text}")
            return None
            
        except requests.exceptions.Timeout:
            logger.error(f"Timeout calling {model}")
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error calling {model}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error calling {model}: {e}")
            return None

    def _get_fallback_response(self, messages: List[Dict[str, str]]) -> str:
        """Generate fallback response based on common financial topics"""
        # Get the last user message
        last_user_message = ""
        for msg in reversed(messages):
            if msg['role'] == 'user':
                last_user_message = msg['content'].lower()
                break
        
        # Topic-based responses
        if 'etf' in last_user_message:
            response = "ETFs (Exchange-Traded Funds) are investment funds that trade on stock exchanges like individual stocks. They typically track an index, commodity, bonds, or a basket of assets, offering diversification at a lower cost than mutual funds."
        elif 'stock' in last_user_message or 'share' in last_user_message:
            response = "Stocks represent ownership shares in a company. When you buy stock, you become a shareholder and own a small piece of that business. Stock prices fluctuate based on company performance and market conditions."
        elif 'bond' in last_user_message:
            response = "Bonds are debt securities where you lend money to an entity (government or corporation) for a defined period at a fixed interest rate. They're generally considered safer than stocks but with lower potential returns."
        elif 'invest' in last_user_message:
            response = "Investing involves putting money into assets with the expectation of generating returns over time. Key principles include diversification, understanding risk tolerance, and having a long-term perspective."
        elif 'compound interest' in last_user_message:
            response = "Compound interest is the interest earned on both the initial principal and previously earned interest. It's often called 'interest on interest' and is a powerful wealth-building tool over time. The earlier you start investing, the more compound interest can work in your favor."
        elif 'risk' in last_user_message and 'return' in last_user_message:
            response = "Risk and return are directly related in investing. Generally, higher potential returns come with higher risk. Lower-risk investments like bonds typically offer smaller returns, while higher-risk investments like stocks can offer greater returns but with more volatility."
        elif 'dollar cost averaging' in last_user_message or 'dca' in last_user_message:
            response = "Dollar-cost averaging is an investment strategy where you invest a fixed amount regularly, regardless of market conditions. This helps reduce the impact of market volatility by buying more shares when prices are low and fewer when prices are high."
        else:
            response = "I'm FinanceBot, your AI financial assistant. I'm here to help with questions about investing, markets, and financial concepts. Feel free to ask about topics like stocks, bonds, ETFs, investing strategies, or market terminology."
        
        return f"{response}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*"