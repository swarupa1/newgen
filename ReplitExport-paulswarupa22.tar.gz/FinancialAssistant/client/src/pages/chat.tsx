import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ChartLine, Send, Bot, User, Info, AlertTriangle } from "lucide-react";
import type { Message } from "@shared/schema";

export default function Chat() {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [messageInput, setMessageInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const quickSuggestions = [
    "What are ETFs?",
    "Explain compound interest",
    "Risk vs return basics",
    "What's the difference between stocks and bonds?",
    "How does dollar-cost averaging work?"
  ];

  // Fetch messages for current session
  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ['/api/messages', sessionId],
    enabled: !!sessionId,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', '/api/messages', {
        content,
        role: 'user',
        sessionId
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/messages', sessionId] });
      setMessageInput("");
      setShowSuggestions(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message"
      });
    }
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sendMessageMutation.isPending]);

  // Auto-resize textarea
  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 128) + 'px';
    }
  };

  const handleSendMessage = () => {
    const content = messageInput.trim();
    if (content && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(content);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setMessageInput(suggestion);
    textareaRef.current?.focus();
  };

  const formatMessageContent = (content: string) => {
    return content.split('\n').map((line, index) => (
      <span key={index}>
        {line}
        {index < content.split('\n').length - 1 && <br />}
      </span>
    ));
  };

  const formatTime = (timestamp: string | Date) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-4 shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
              <ChartLine className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">FinanceBot</h1>
              <p className="text-sm text-slate-600">AI Financial Assistant</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>Online</span>
          </div>
        </div>
      </header>

      {/* Main Chat Container */}
      <main className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
          {/* Welcome Message */}
          {messages.length === 0 && !isLoading && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-white w-4 h-4" />
              </div>
              <div className="bg-white rounded-lg rounded-tl-none px-4 py-3 shadow-sm border max-w-3xl">
                <p className="text-gray-800 leading-relaxed">
                  Welcome to FinanceBot! I'm here to help you with financial questions, market insights, and investment basics. 
                  How can I assist you today?
                </p>
                <span className="text-xs text-slate-600 mt-2 block">Just now</span>
              </div>
            </div>
          )}

          {/* Message History */}
          {messages.map((message) => (
            <div 
              key={message.id} 
              className={`flex items-start space-x-3 ${message.role === 'user' ? 'justify-end' : ''}`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="text-white w-4 h-4" />
                </div>
              )}
              
              <div className={`rounded-lg px-4 py-3 shadow-sm max-w-3xl ${
                message.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-white border rounded-tl-none'
              }`}>
                <p className={`leading-relaxed ${message.role === 'user' ? 'text-white' : 'text-gray-800'}`}>
                  {formatMessageContent(message.content)}
                </p>
                <span className={`text-xs mt-2 block ${
                  message.role === 'user' ? 'text-blue-100' : 'text-slate-600'
                }`}>
                  {formatTime(message.timestamp)}
                </span>
              </div>

              {message.role === 'user' && (
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="text-gray-600 w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {/* Typing Indicator */}
          {sendMessageMutation.isPending && (
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="text-white w-4 h-4" />
              </div>
              <div className="bg-white rounded-lg rounded-tl-none px-4 py-3 shadow-sm border">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:0.1s]"></div>
                  <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                </div>
                <span className="text-xs text-slate-600 mt-2 block">FinanceBot is typing...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <div className="border-t border-gray-200 bg-white px-4 py-4">
          <div className="flex items-end space-x-3">
            <div className="flex-1">
              <Textarea
                ref={textareaRef}
                value={messageInput}
                onChange={(e) => {
                  setMessageInput(e.target.value);
                  adjustTextareaHeight();
                }}
                onKeyPress={handleKeyPress}
                placeholder="Ask me about finance, investments, market terms..."
                className="w-full resize-none border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent min-h-[52px] max-h-32"
                rows={1}
                disabled={sendMessageMutation.isPending}
              />
            </div>
            <Button 
              onClick={handleSendMessage}
              disabled={!messageInput.trim() || sendMessageMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 min-w-[100px]"
            >
              <Send className="w-4 h-4 mr-2" />
              Send
            </Button>
          </div>
        </div>
      </main>

      {/* Quick Suggestions */}
      {showSuggestions && messages.length === 0 && (
        <div className="fixed bottom-20 right-4 hidden lg:block">
          <Card className="p-4 w-64 shadow-lg">
            <h3 className="font-medium text-gray-900 mb-3 text-sm">Quick Questions</h3>
            <div className="space-y-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full text-left p-2 text-sm text-slate-600 hover:bg-gray-50 rounded transition-colors duration-200"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* Disclaimer Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 px-4 py-3">
        <div className="max-w-4xl mx-auto">
          <p className="text-xs text-slate-600 text-center leading-relaxed">
            <Info className="inline w-3 h-3 mr-1" />
            <strong>Disclaimer:</strong> This AI assistant provides general financial information for educational purposes only. 
            It does not constitute professional financial advice. Always consult with qualified financial professionals before making investment decisions.
          </p>
        </div>
      </footer>
    </div>
  );
}
