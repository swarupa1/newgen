# Finance Bot Chat Application

## Overview

This is a full-stack React application that provides a finance-focused AI chatbot interface. The application features a clean, modern UI built with React and shadcn/ui components on the frontend, with an Express.js backend that integrates with OpenAI's GPT-4 API to provide educational financial information and guidance.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Integration**: OpenAI GPT-4 API for AI responses
- **Database**: Drizzle ORM configured for PostgreSQL with Neon serverless
- **Storage**: Dual storage implementation (memory-based and database-ready)

## Key Components

### Frontend Components
- **Chat Interface**: Main chat page with message history, input field, and quick suggestions
- **UI Components**: Comprehensive set of reusable components from shadcn/ui including buttons, cards, dialogs, forms, and more
- **Responsive Design**: Mobile-first approach with responsive layouts

### Backend Components
- **API Routes**: RESTful endpoints for message management
- **OpenAI Integration**: Specialized finance bot with educational focus
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database persistence
- **Middleware**: Logging, error handling, and request parsing

### Database Schema
- **Users Table**: Basic user management (id, username, password)
- **Messages Table**: Chat message storage (id, content, role, sessionId, timestamp)
- **Session Management**: Session-based conversation tracking

## Data Flow

1. **User Interaction**: User types a message in the chat interface
2. **API Request**: Frontend sends POST request to `/api/messages` with message content
3. **Message Storage**: Backend saves user message to storage
4. **Context Retrieval**: System retrieves recent conversation history (last 10 messages)
5. **AI Processing**: OpenAI API generates response based on conversation context and finance-focused system prompt
6. **Response Storage**: AI response is saved to storage
7. **Frontend Update**: React Query invalidates cache and refetches updated conversation
8. **UI Render**: New messages appear in the chat interface

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **openai**: Official OpenAI API client
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitive components
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **vite**: Build tool and development server
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

## Deployment Strategy

### Development
- Uses tsx for TypeScript execution with hot reloading
- Vite development server with HMR for frontend
- Memory-based storage for quick development iteration
- Replit-specific plugins for development environment integration

### Production Build
- **Frontend**: Vite builds React app to static assets in `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations system for schema management
- **Environment**: Configured for Neon PostgreSQL in production

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API authentication
- `NODE_ENV`: Environment specification (development/production)

### File Structure
- `client/`: React frontend application
- `server/`: Express backend application  
- `shared/`: Shared TypeScript types and database schema
- `migrations/`: Drizzle database migration files

The application is designed to be easily deployable on Replit with automatic environment setup and can scale from development (memory storage) to production (PostgreSQL) seamlessly.