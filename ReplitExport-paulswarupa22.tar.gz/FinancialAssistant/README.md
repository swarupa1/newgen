# Finance Chatbot Application

A full-stack finance chatbot built with React, TypeScript, and Express.js that provides AI-powered financial education and guidance.

## 🚀 Features

- **AI-Powered Finance Assistant**: Get answers to financial questions about investing, markets, and financial concepts
- **Modern UI**: Clean, responsive interface built with React and shadcn/ui components
- **Real-time Chat**: Interactive chat interface with typing indicators
- **Session Management**: Conversation history maintained per session
- **Educational Focus**: Provides educational financial information with appropriate disclaimers
- **Fallback Responses**: Smart fallback answers when AI service is unavailable

## 🛠️ Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling
- **Wouter** for routing
- **TanStack Query** for state management
- **shadcn/ui** components with Radix UI
- **Tailwind CSS** for styling
- **Framer Motion** for animations

### Backend
- **Express.js** with TypeScript
- **Drizzle ORM** for database operations
- **PostgreSQL** database support
- **Hugging Face API** for AI responses
- **Session-based storage**

## 📦 Installation

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd finance-chatbot
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
Create a `.env` file in the root directory:
```env
DATABASE_URL=your_postgresql_database_url
HUGGINGFACE_API_KEY=your_huggingface_api_key
NODE_ENV=development
PORT=5000
```

4. **Run database migrations** (if using PostgreSQL)
```bash
npm run db:push
```

5. **Start the development server**
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 🌐 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL database connection URL | No (uses memory storage if not provided) |
| `HUGGINGFACE_API_KEY` | Hugging Face API key for AI responses | Yes |
| `NODE_ENV` | Environment (development/production) | No (defaults to development) |
| `PORT` | Server port | No (defaults to 5000) |

## 📋 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run check` - Run TypeScript type checking
- `npm run db:push` - Push database schema changes

## 🗄️ Database Schema

The application uses two main tables:

### Users Table
- `id` - Primary key
- `username` - Unique username
- `password` - Hashed password

### Messages Table
- `id` - Primary key
- `content` - Message content
- `role` - Either 'user' or 'assistant'
- `sessionId` - Session identifier
- `timestamp` - Message timestamp

## 🤖 AI Integration

The application integrates with Hugging Face's inference API using:
- Primary model: `microsoft/DialoGPT-large`
- Fallback model: `facebook/blenderbot-400M-distill`
- Built-in fallback responses for common financial topics

## 🎨 UI Components

The application uses shadcn/ui components including:
- Button, Card, Dialog components
- Form controls (Textarea, Input)
- Toast notifications
- Responsive layout components

## 📱 Responsive Design

- Mobile-first approach
- Responsive breakpoints
- Touch-friendly interface
- Optimized for desktop and mobile devices

## 🔧 Development

### Project Structure
```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   └── main.tsx        # Application entry point
│   └── index.html
├── server/                 # Backend Express application
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── openai.ts          # AI integration
│   ├── storage.ts         # Database abstraction
│   └── vite.ts            # Vite development server
├── shared/                # Shared types and schemas
│   └── schema.ts          # Database schema definitions
└── package.json
```

### Adding New Features

1. **Database Changes**: Update `shared/schema.ts` and run `npm run db:push`
2. **API Routes**: Add new routes in `server/routes.ts`
3. **Frontend Pages**: Add new pages in `client/src/pages/` and update routing in `App.tsx`
4. **UI Components**: Use existing shadcn/ui components or add new ones in `client/src/components/ui/`

## 🚀 Deployment

### Production Build
```bash
npm run build
npm run start
```

### Environment Setup
- Ensure all environment variables are set
- Use a production PostgreSQL database
- Set `NODE_ENV=production`

## 🔐 Security Considerations

- All user inputs are validated using Zod schemas
- Environment variables for sensitive data
- Session-based conversation management
- Input sanitization for AI responses

## 📄 License

MIT License - see LICENSE file for details

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📞 Support

For questions or issues, please:
- Check the existing issues
- Create a new issue with detailed description
- Include error logs and environment details

---

**Note**: This application provides educational financial information only and should not be considered as professional financial advice. Always consult with qualified financial professionals for investment decisions.