export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export async function generateFinanceResponse(messages: ChatMessage[]): Promise<string> {
  try {
    const systemPrompt = `You are FinanceBot, an AI financial assistant specialized in providing helpful, accurate, and educational information about finance, investing, and markets. 

Key guidelines:
- Provide clear, educational responses about financial topics
- Use simple language that both beginners and professionals can understand
- Include relevant examples when helpful
- Always remind users that this is educational information, not personalized financial advice
- Focus on topics like: stocks, bonds, ETFs, investing basics, market terminology, financial planning concepts
- If asked about specific stock picks or investment recommendations, politely redirect to general education
- Be professional yet approachable
- Keep responses concise but comprehensive

Remember: Always include a disclaimer that this is educational information only and users should consult with qualified financial professionals for personalized advice.`;

    // Build conversation context for Hugging Face
    const conversationText = messages.map(msg => 
      `${msg.role === 'user' ? 'Human' : 'Assistant'}: ${msg.content}`
    ).join('\n\n');
    
    const prompt = `${systemPrompt}\n\nConversation:\n${conversationText}\n\nAssistant:`;

    const response = await fetch('https://api-inference.huggingface.co/models/microsoft/DialoGPT-large', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_length: 1000,
          temperature: 0.7,
          do_sample: true,
          top_p: 0.9,
          repetition_penalty: 1.1
        }
      })
    });

    if (!response.ok) {
      // Try alternative model if primary fails
      const fallbackResponse = await fetch('https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: conversationText,
          parameters: {
            max_length: 500,
            temperature: 0.7
          }
        })
      });

      if (!fallbackResponse.ok) {
        throw new Error(`Hugging Face API error: ${response.status}`);
      }

      const fallbackData = await fallbackResponse.json();
      const aiResponse = fallbackData.generated_text || fallbackData[0]?.generated_text || "I'm here to help with your financial questions. Could you please rephrase your question?";
      
      return `${aiResponse}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*`;
    }

    const data = await response.json();
    const aiResponse = data.generated_text || data[0]?.generated_text || "I'm here to help with your financial questions. Could you please try asking again?";
    
    // Clean up the response to remove the prompt and format nicely
    const cleanResponse = aiResponse.replace(prompt, '').trim();
    
    return `${cleanResponse}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*`;
    
  } catch (error) {
    console.error("Hugging Face API error:", error);
    
    // Provide a helpful fallback response based on the user's question
    const lastUserMessage = messages.filter(msg => msg.role === 'user').pop();
    const topic = lastUserMessage?.content.toLowerCase() || '';
    
    let fallbackResponse = "I'm FinanceBot, your AI financial assistant. I'm here to help with questions about investing, markets, and financial concepts.";
    
    if (topic.includes('etf')) {
      fallbackResponse = "ETFs (Exchange-Traded Funds) are investment funds that trade on stock exchanges like individual stocks. They typically track an index, commodity, bonds, or a basket of assets, offering diversification at a lower cost than mutual funds.";
    } else if (topic.includes('stock') || topic.includes('share')) {
      fallbackResponse = "Stocks represent ownership shares in a company. When you buy stock, you become a shareholder and own a small piece of that business. Stock prices fluctuate based on company performance and market conditions.";
    } else if (topic.includes('bond')) {
      fallbackResponse = "Bonds are debt securities where you lend money to an entity (government or corporation) for a defined period at a fixed interest rate. They're generally considered safer than stocks but with lower potential returns.";
    } else if (topic.includes('invest')) {
      fallbackResponse = "Investing involves putting money into assets with the expectation of generating returns over time. Key principles include diversification, understanding risk tolerance, and having a long-term perspective.";
    } else if (topic.includes('compound interest')) {
      fallbackResponse = "Compound interest is the interest earned on both the initial principal and previously earned interest. It's often called 'interest on interest' and is a powerful wealth-building tool over time. The earlier you start investing, the more compound interest can work in your favor.";
    } else if (topic.includes('risk') && topic.includes('return')) {
      fallbackResponse = "Risk and return are directly related in investing. Generally, higher potential returns come with higher risk. Lower-risk investments like bonds typically offer smaller returns, while higher-risk investments like stocks can offer greater returns but with more volatility.";
    } else if (topic.includes('dollar cost averaging') || topic.includes('dca')) {
      fallbackResponse = "Dollar-cost averaging is an investment strategy where you invest a fixed amount regularly, regardless of market conditions. This helps reduce the impact of market volatility by buying more shares when prices are low and fewer when prices are high.";
    }
    
    return `${fallbackResponse}\n\n*Disclaimer: This is educational information only. Please consult with qualified financial professionals for personalized advice.*`;
  }
}