import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { generateFinanceResponse, type ChatMessage } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get chat history for a session
  app.get("/api/messages/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getMessages(sessionId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send a message and get AI response
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      
      // Save user message
      const userMessage = await storage.createMessage(messageData);
      
      // Get conversation history for context
      const conversationHistory = await storage.getMessages(messageData.sessionId);
      
      // Prepare messages for OpenAI (last 10 messages for context)
      const chatMessages: ChatMessage[] = conversationHistory
        .slice(-10)
        .map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content
        }));

      // Generate AI response
      const aiResponse = await generateFinanceResponse(chatMessages);
      
      // Save AI response
      const assistantMessage = await storage.createMessage({
        content: aiResponse,
        role: 'assistant',
        sessionId: messageData.sessionId
      });

      res.json({
        userMessage,
        assistantMessage
      });
    } catch (error) {
      console.error("Error processing message:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process message" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
